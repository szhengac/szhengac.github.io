function rmse = SampleTest()
% function rmse = computeRMSE(predictions, labels)

% A Sample of training and testing 
%
% Outputs: 
%   rmse - scalar; root mean square error
%  
% Author: Shuai Zheng (szhengac@cse.ust.hk), according to paper Zheng et al., 
%         'Accurate integration of aerosol predictions by smoothing on a manifold', AAAI 2014.
% Date  : August 6th, 2014

% generate training sample
[X_train, Y_train, Date_train, ground_truth, test_label] = generate_toy_data(200, 200, 0);

% training stage
[Sigma, scale_parameter, m_R, q, Lambda] = aerosol_train(ground_truth, Y_train, X_train, Date_train, 2);

% generate testing sample
[X_test, Y_test, Date_test, ground_truth, test_label] = generate_toy_data(200, 200, 0);

% testing stage
rmse = aerosol_test(Sigma, Y_test, X_test, Date_test, test_label, ground_truth, scale_parameter, m_R, q, Lambda);
end