function [X, Y, Date, ground_truth, test_label] = generate_toy_data(N_l, N_u, noise_var)

% function [X, Y, ground_truth, Date, test_label] = generate_toy_data(N_l, N_u, noise_var)

% Generate toy data
%
% Inputs: 
%   N_l       - scalar, represents the number of labeled data
%   N_u       - scalar, represents the number of unlabeled data; 
%   noise_var - scalar, vaiance of the normal distribution generating noise
%
% Outputs: 
%   Y            - (N x K) array, each row represents measurements of K experts for one example; 
%                   NaN denotes missing expert prediction
%   X            - (N x D) array, each row represents geographic information (latitude and longitude) for one example;
%   Date         - (N x 1) array, each element represents collected time point for one example;
%   ground_truth - (N x 1) array; NaN denotes missing label
%   test_label   - (N x 1) array; contains all the labels

 
% Author: Shuai Zheng (szhengac@cse.ust.hk), according to paper Zheng et al., 
%         'Accurate integration of aerosol predictions by smoothing on a manifold', AAAI 2014.
% Date  : August 6th, 2014

% default number of experts
K = 5;
% default geographic information (latitude and longitude) for regime 1
mu1 = [38 -100]; 
% default geographic information (latitude and longitude) for regime 2
mu2 = [38 100];
% default covariance matrix for generating locations 
SIGMA_X = [20 0; 0 60];
% default covariance matrix for generating expert measurements 
SIGMA_Y = diag([0.01 0.02 0.03 0.04 0.05]);
ones_vec = ones(1, K);
N = N_l + N_u;
X = zeros(N, 2);
Date = cell(N, 1);
clusters = zeros(N, 1);
m_1 = zeros(N, 1);
m_2 = zeros(N, 1);
% default scale parameter
sigma = 0.01;
% default regularzation coefficient
alpha = 1;

% generate locations and assign AOD mean
for i = 1 : N
    % assign location to regime with probability 0.5
    if rand >= 0.5
        X(i, :) = mvnrnd(mu1, SIGMA_X);
        m_1(i) = 0.1;
        clusters(i) = 1;
    else
        X(i, :) = mvnrnd(mu2, SIGMA_X);
        m_2(i) = 0.2;
        clusters(i) = 2;
    end
end

m_R = m_1 + m_2;
laplacian_matrix = computelaplacianMatrix(X, N, 0);
% generate gruth truth
ground_truth = mvnrnd(m_R, inv(laplacian_matrix + alpha * eye(N)) * sigma);
% add noise to gruth truth
noise = randn(size(ground_truth, 1), size(ground_truth, 2)) .* noise_var;
ground_truth = ground_truth + noise;

ground_truth = ground_truth';
test_label = ground_truth;
% generate expert predictions
Y = mvnrnd(ground_truth * ones_vec, SIGMA_Y);
% randomly select N_u elements to be unlabel locations
rand_index = randperm(N);
ground_truth(rand_index(1 : N_u)) = NaN;

% generate missing experts with probability 0.5 
missing_ind = rand(size(Y)) >= 0.5;
for i = 1 : N
    miss_ind = missing_ind(i, :);
    % make sure not all the expert measurements are missing
    if (sum(miss_ind) == K)
        miss_ind(ceil(K * rand)) = false;
        missing_ind(i, :) = miss_ind;
    end;
end;
% NaN entries denote missing data
Y(missing_ind) = NaN;

% partition locations into different time points uniformly
T_range = {'2006-01-01', '2006-01-02', '2006-01-03', '2006-01-04', '2006-01-05', '2006-01-06', '2006-01-07', '2006-01-08', '2006-01-09', '2006-01-10'};
Date(:) = randsample(T_range, N, true)';

end