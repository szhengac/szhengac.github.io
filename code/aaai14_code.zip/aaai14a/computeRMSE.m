function rmse = computeRMSE(predictions, labels)
% function rmse = computeRMSE(predictions, labels)

% Compute root mean square error
%
% Inputs: 
%   predictions - (N x 1) array; each element represents the prediction for one data point 
%   labels      - (N x 1) array, each element represents the label for one data point; 
%
% Outputs: 
%   rmse            - scalar; root mean square error
%  
% Author: Shuai Zheng (szhengac@cse.ust.hk), according to paper Zheng et al., 
%         'Accurate integration of aerosol predictions by smoothing on a manifold', AAAI 2014.
% Date  : August 6th, 2014

rmse = sqrt(mse(predictions - labels));

end