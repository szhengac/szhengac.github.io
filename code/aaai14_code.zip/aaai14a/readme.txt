Here is the implementation of method, described in:
Zheng et al., 'Accurate Integration of Aerosol Predictions by Smoothing on a Manifold', AAAI 2014. In order to try the code, 
run the following commands in Matlab command prompt:

file SampleTest.m shows an example of trying the code

Please send any comments and/or suggestions you might have to: 
szhengac@cse.ust.hk