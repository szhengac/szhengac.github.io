function laplacian_matrix = computelaplacianMatrix(X, N, ida)

% function laplacian_matrix = computelaplacianMatrix(X, N, ida)

% Compute the Laplacian matrix of locations
%
% Inputs: 
%   X  - (N x 2) array; each row represents geographic information (latitude and longitude) for one location;
%   N  - scalar, represents the number of locations; 
%   ida  - scalar, 0 for data generation process;
%                  1 for training and testing phrases
%
% Outputs: 
%   laplacian_matrix  - (N x N) array; Laplacian matrix
 
% Author: Shuai Zheng (szhengac@cse.ust.hk), according to paper Zheng et al., 
%         'Accurate integration of aerosol predictions by smoothing on a manifold', AAAI 2014.
% Date  : August 6th, 2014

% radius of Earth
radius = 6371;

laplacian_matrix = zeros(N);

k = 5;
dist_matrix = zeros(N);

for i = 1 : N
    for j = 1 : i - 1
        % compute great-circle distance by haversine formula
        d = 2 * radius * asin(sqrt(sin((X(i, 1) - X(j, 1)) /2 )^2 + cos(X(i, 1)) * cos(X(j, 1)) * sin((X(i, 2) - X(j, 2)) /2 )^2));
        dist_matrix(i, j) = d;
        dist_matrix(j, i) = d;
    end
end

% find the Kth nearest neighbor for each location
sortedValues = sort(dist_matrix,'ascend'); 
d_k = sortedValues(k + 1, :)';
d_k = sqrt(d_k);

% compute laplacian matrix
for i = 1 : N
    for j = 1 : i - 1 
        d = dist_matrix(i, j);    
        if (ida == 1)
            laplacian_matrix(i, j) = exp(-d/(d_k(i) * d_k(j)));
        elseif (ida == 0)
            laplacian_matrix(i, j) = exp(-d / 1000);
        end     
        laplacian_matrix(j, i) = laplacian_matrix(i, j);
    end
end

laplacian_matrix = diag(sum(laplacian_matrix)) - laplacian_matrix;
end