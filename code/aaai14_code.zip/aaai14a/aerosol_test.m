function rmse = aerosol_test(Sigma, Y_test, X_test, Date_test, test_label, ground_truth, scale_parameter, m_R, q, Lambda)

% function rmse = aerosol_test(Sigma, Y_test, X_test, Date_test, test_label, ground_truth, scale_parameter, m_R, q, Lambda)

% predict the ground truth for the unlabeled data point and return the rmse result
%
% Inputs: 
%   Sigma            - (K x K) array; covariance matrix
%   Y_test           - (N x K) array, each row represents measurements of K experts for one testing example; NaN denotes missing expert prediction
%   X_test           - (N x D) array, each row represents geographic information (latitude and longitude) for one testing example;
%   Date_test        - (N x 1) array, each element represents collected time point for one testing example;
%   test_label       - (N x 1) array; contains all the labels
%   ground_truth     - (N x 1) array; NaN denotes missing label
%   scale_parameter  - scalar, scales the covariance matrix Sigma to a proper magnitude
%   m_R              - (R x 1) array, each element represents the default AOD mean for one regime;
%   q                - (R x 2) array, each row is a prototype vector for one regime;
%   Lambda           - (R x 1) cell array, each element represents a scaling matrix for one regime;
%
% Outputs: 
%   rmse             - scalar; root mean of square error
%
% Author: Shuai Zheng (szhengac@cse.ust.hk), according to paper Zheng et al., 
%         'Accurate integration of aerosol predictions by smoothing on a manifold', AAAI 2014.
% Date  : August 6th, 2014

K = size(Sigma, 1);
R = length(m_R);
[ground_truth_T, Y_test_T, X_test_T, test_label_T, T] = arrangeDataWithTime(ground_truth, Y_test, X_test, test_label, Date_test);
rv = 1 / scale_parameter;
% regularzation coefficient
alpha = 1;

Sigma_inv = inv(Sigma);

Yu_test_T = cell(T, 1);
y_u_T = cell(T, 1);
y_l_T = cell(T, 1);
N_u_T = cell(T, 1);
N_l_T = cell(T, 1);
% indices of missing measurements in experts matrix
missing_ind_test_T = cell(T, 1);
% spatial correlations between unlabeled data in each time point
laplacian_u_matrix_T = cell(T, 1);
% spatial correlations between labeled data and unlabeled in each time point
laplacian_lu_matrix_T = cell(T, 1);
pi_ir_T = cell(T, 1);
m_train_T = cell(T, 1);

% predictions of unlabeled data
yu = [];
% labels of unlabeled data
yu_label = [];

% partition the data points according to corresponding collected time point
for t = 1 : T
    ind_labeled = ~isnan(ground_truth_T{t});
    Y_test_T{t} = [Y_test_T{t}(~ind_labeled, :); Y_test_T{t}(ind_labeled, :)];
    ground_truth_T{t} = [ground_truth_T{t}(~ind_labeled); ground_truth_T{t}(ind_labeled)];
    X_test_T{t} = [X_test_T{t}(~ind_labeled, :); X_test_T{t}(ind_labeled, :)];
    test_label_T{t}(ind_labeled) = [];
    
    ind_labeled = ~isnan(ground_truth_T{t});
    Yu_test_T{t} = Y_test_T{t}(~ind_labeled, :);
    missing_ind_test_T{t} = isnan(Yu_test_T{t});        
    y_l_T{t} = ground_truth_T{t}(ind_labeled);   
    
    N_u_T{t} = sum(~ind_labeled);
    N_l_T{t} = sum(ind_labeled);
    N_T = N_u_T{t} + N_l_T{t};
    
    laplacian_matrix = computelaplacianMatrix(X_test_T{t}, N_T, 1) + alpha * eye(N_T);
    laplacian_u_matrix_T{t} = laplacian_matrix(1 : N_u_T{t}, 1 : N_u_T{t});
    laplacian_lu_matrix_T{t} = laplacian_matrix(N_u_T{t} + 1 : N_T, 1 : N_u_T{t});
    
    pi_ir_T{t} = zeros(N_T, R);
    m_train_T{t} = zeros(N_T, 1);
end

% compute the probability of each data point belongs to each regime
for t = 1 : T
    N_T = N_u_T{t} + N_l_T{t};
    for i = 1 : N_T
        for r = 1 : R
            pi_ir_T{t}(i, r) = exp(-(X_test_T{t}(i, :) - q(r, :)) * Lambda{r} * (X_test_T{t}(i, :) - q(r, :))');
        end;
        pi_ir_T{t}(i, :) = pi_ir_T{t}(i, :) / sum(pi_ir_T{t}(i, :));
        m_train_T{t}(i) = pi_ir_T{t}(i, :) * m_R;
    end;
end;

% compute the predictions of unlabeled data points
for t = 1 : T
    N_u = N_u_T{t};
    if (N_u > 0)
        N_l = N_l_T{t};
        missing_ind_test = missing_ind_test_T{t};
        y_l = y_l_T{t};
        Yu_test = Yu_test_T{t};
        laplacian_u_matrix = laplacian_u_matrix_T{t};
        laplacian_lu_matrix = laplacian_lu_matrix_T{t};
        
        U_tilde_Nu = zeros(N_u);
        Y_tilde_Nu = zeros(N_u, 1);
        
        for i = 1 : N_u
            miss_ind = missing_ind_test(i, :);
            non_miss_ind = ~miss_ind;
            if (sum(miss_ind) == K)
                error('Error, all experts are missing for a testing example!');
            end
            
            Q_mat = Sigma_inv(miss_ind, miss_ind);
            V_mat = Sigma_inv(non_miss_ind, miss_ind);
            ones_vector = ones(sum(non_miss_ind), 1);
            U_mat = Sigma_inv(non_miss_ind, non_miss_ind);
            V_mat_div_Q_mat = V_mat / Q_mat;
            U_prim_mat = U_mat - V_mat_div_Q_mat * V_mat';
            
            U_tilde_Nu(i, i) = sum(U_prim_mat(:));
            Y_tilde_Nu(i) = Yu_test(i, non_miss_ind) * U_prim_mat * ones_vector;
        end
        
        if (N_l > 0)
            y_u_T{t} = (U_tilde_Nu + rv * laplacian_u_matrix) \ (Y_tilde_Nu - rv * laplacian_lu_matrix' * y_l + rv * laplacian_lu_matrix' * m_train_T{t}(N_u_T{t} + 1 : end) + rv * laplacian_u_matrix * m_train_T{t}(1 : N_u_T{t}));
        else
            y_u_T{t} = (U_tilde_Nu + rv * laplacian_u_matrix) \ (Y_tilde_Nu + rv * laplacian_u_matrix * m_train_T{t}(1 : N_u_T{t}));
        end
        yu = [yu; y_u_T{t}];
        yu_label = [yu_label; test_label_T{t}];
    end
end


rmse = computeRMSE(yu, yu_label);
end

function [ground_truth_T, Y_test_T, X_test_T, test_label_T, T] = arrangeDataWithTime(ground_truth, Y_test, X_test, test_label, Date_test)
[C, ~, ~] = unique(Date_test);
T = length(C);

Y_test_T = cell(T, 1);
X_test_T = cell(T, 1);
ground_truth_T = cell(T, 1);
test_label_T = cell(T, 1);

for i = 1 : T
    pos = strcmp(Date_test, C{i});
    ground_truth_T{i} = ground_truth(pos, :);
    Y_test_T{i} = Y_test(pos, :);
    X_test_T{i} = X_test(pos, :) .* pi / 180;
    test_label_T{i} = test_label(pos, :);
end

end
