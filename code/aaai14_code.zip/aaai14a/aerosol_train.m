function [Sigma, scale_parameter, m_R, q, Lambda] = aerosol_train(ground_truth, Y_train, X_train, Date_train, R)

% function [Sigma, scale_parameter, m_R, q, Lambda] = aerosol_train(ground_truth, Y_train, X_train, Date_train, R)

% Train the model to learn the corresponding parameters
%
% Inputs: 
%   ground_truth - (N x 1) array; NaN denotes missing label
%   Y_train      - (N x K) array, each row represents measurements of K experts for one training example; 
%                   NaN denotes missing expert prediction
%   X_train      - (N x D) array, each row represents geographic information (latitude and longitude) for one training example;

%   Date_train   - (N x 1) array, each element represents collected time point for one training example;
%   R            - number of regimes that generated the training data
%
% Outputs: 
%   Sigma            - (K x K) array; covariance matrix
%   scale_parameter  - scalar, scales the covariance matrix Sigma to a proper magnitude
%   m_R              - (R x 1) array, each element represents the default AOD mean for one regime;
%   q                - (R x 2) array, each row is a prototype vector for one regime;
%   Lambda           - (R x 1) cell array, each element represents a scaling matrix for one regime;
%  
% Author: Shuai Zheng (szhengac@cse.ust.hk), according to paper Zheng et al., 
%         'Accurate integration of aerosol predictions by smoothing on a manifold', AAAI 2014.
% Date  : August 6th, 2014

%% model parameters initialization

[N, K] = size(Y_train);

% learning rate for covariance matrix
learning_rate_Sigma = 6;
% learning rate for scale parameter
learning_rate_scale_parameter = 6;
% learning rate for prototype vector
learning_rate_q = 1;
% learning rate for scaling matrix
learning_rate_Lambda = 1;
% regularzation coefficient
alpha = 1;

Sigma = eye(K);
Sigma_inv = inv(Sigma);
scale_parameter = 1;
m_R = zeros(R, 1);
Lambda = cell(R, 1);
q = zeros(R, size(X_train, 2));

% use k-means to initialize the regimes
if (R > 1)
    partition = kmeans(X_train, R, 'emptyaction', 'singleton');
    for r = 1 : R
        pa = partition == r;
        q(r, :) = mean(X_train(pa, :));        
        if (~isnan(nanmean(ground_truth(pa))))
            m_R(r) = nanmean(ground_truth(pa));
        end
    end
else
    q = mean(X_train);
    if (~isnan(nanmean(ground_truth)))
        m_R = nanmean(ground_truth);
    end
end

% convert degree to radians
X_train = X_train .* pi / 180;
q = q .* pi / 180;

% assign each data point with corresponding collected time point
[Date_class, T] = assignDataWithTime(Date_train);

N_u_T = cell(T, 1);
N_l_T = cell(T, 1);
laplacian_matrix_T = cell(T, 1);
% spatial correlations between labeled data in each time point
laplacian_l_matrix_T = cell(T, 1);
% spatial correlations between unlabeled data in each time point
laplacian_u_matrix_T = cell(T, 1);
% spatial correlations between labeled data and unlabeled in each time point
laplacian_lu_matrix_T = cell(T, 1);
X_train_T = cell(T, 1);
U_tilde_Nu_T = cell(T, 1);
Y_tilde_Nu_T = cell(T, 1);
vi_T = cell(T, 1);
Phi_T = cell(T, 1);
Psi_T = cell(T, 1);
ones_vector_u_T = cell(T, 1);
ones_vector_l_T = cell(T, 1);
vector_diagonal_matrixs_T = cell(T, 1);
vector_mixed_matrixs_T = cell(T, 1);
pi_ir_T = cell(T, 1);
m_train_T = cell(T, 1);
Q_train_T = cell(T, 1);
B_train_T = cell(T, 1);
        
ind_labeled = ~isnan(ground_truth);
Nu = sum(~ind_labeled);
Nl = sum(ind_labeled);
Y_train = [Y_train(~ind_labeled, :); Y_train(ind_labeled, :)];
ground_truth = [ground_truth(~ind_labeled); ground_truth(ind_labeled)];
X_train = [X_train(~ind_labeled, :); X_train(ind_labeled, :)];
Date_class = [Date_class(~ind_labeled, :); Date_class(ind_labeled, :)];
Yu_train = Y_train(1 : Nu, :);
% indices of missing measurements in experts matrix
missing_ind_train = isnan(Y_train);
Yu_train = Yu_train';
Yu_train = Yu_train';
y_l = ground_truth(Nu + 1 : end);

% partition the data points according to corresponding collected time point
for i = 1 : T  
    pos = Date_class == i;
    ind_labeled = ~isnan(ground_truth(pos));
    N_u_T{i} = sum(~ind_labeled);
    N_l_T{i} = sum(ind_labeled);
    N_T = N_u_T{i} + N_l_T{i};   
    X_train_T{i} = X_train(pos, :);
    laplacian_matrix = computelaplacianMatrix(X_train_T{i}, N_T, 1) + alpha * eye(N_T);
    laplacian_l_matrix_T{i} = laplacian_matrix(N_u_T{i} + 1 : N_T, N_u_T{i} + 1 : N_T);
    laplacian_u_matrix_T{i} = laplacian_matrix(1 : N_u_T{i}, 1 : N_u_T{i});
    laplacian_lu_matrix_T{i} = laplacian_matrix(N_u_T{i} + 1 : N_T, 1 : N_u_T{i});
    laplacian_matrix_T{i} = laplacian_matrix;

    U_tilde_Nu_T{i} = zeros(N_u_T{i});
    Y_tilde_Nu_T{i} = zeros(N_u_T{i}, 1);
    vi_T{i} = zeros(N_u_T{i}, 1);
    Phi_T{i} = zeros(K);
    Psi_T{i} = zeros(K);
    vector_diagonal_matrixs_T{i} = zeros(K, K, N_u_T{i});
    vector_mixed_matrixs_T{i} = zeros(K, K, N_u_T{i});
    ones_vector_u_T{i} = ones(N_u_T{i}, 1);
    ones_vector_l_T{i} = ones(N_l_T{i}, 1);
    
    pi_ir_T{i} = zeros(N_T, R);
    m_train_T{i} = zeros(N_T, 1);
    Q_train_T{i} = zeros(size(X_train, 2), N_T);
    B_train_T{i} = zeros(N_T, N_T);
end

Sigma_gradient = zeros(K);
rv_gradient = 0;
q_gradient = zeros(R, size(X_train, 2));
Lambda_gradient = cell(R, 1);
for r = 1 : R
    Lambda{r} = eye(size(X_train, 2));
    Lambda_gradient{r} = eye(size(X_train, 2));
end;

collected_num_T = ones(T, 1);
m_nominator = zeros(R, 1);
m_denominator = zeros(R, 1);

rv = 1 / scale_parameter;
rstd =  1 / sqrt(scale_parameter);

% outer number of iterations
iters = 0;
% inner number of iterations for training covariance matrix
Sigma_iters = 50;
% inner number of iterations for training scale parameter
scale_parameter_iters = 5;
% inner number of iterations for training default AOD means
mu_iters = 5;

%% model training

while (iters < 15)
   % compute the probability of each data point belongs to each regime
   for t = 1 : T
        N_T = N_u_T{t} + N_l_T{t};
        for i = 1 : N_T
            for r = 1 : R
                pi_ir_T{t}(i, r) = exp(-(X_train_T{t}(i, :) - q(r, :)) * Lambda{r} * (X_train_T{t}(i, :) - q(r, :))');
            end;
            pi_ir_T{t}(i, :) = pi_ir_T{t}(i, :) / sum(pi_ir_T{t}(i, :));
            m_train_T{t}(i) = pi_ir_T{t}(i, :) * m_R;
        end;
    end;
    
    % gradient ascent on covariance matrix
    for n = 1 : Sigma_iters + 1
        Sigma = inv(Sigma_inv);
        Sigma_gradient(:) = 0;
        collected_num_T(:) = 1;
        
        % collect gradient information from labeled data points
        for i = Nu + 1: N
            miss_ind = missing_ind_train(i, :);
            non_miss_ind = ~miss_ind;
            
            Q_mat = Sigma_inv(miss_ind, miss_ind);
            V_mat = Sigma_inv(non_miss_ind, miss_ind);
            V_mat_div_Q_mat = V_mat / Q_mat;
            
            temp = zeros(K);
            temp(miss_ind, miss_ind) = inv(Q_mat);
            temp = temp + get_missing_data_matrix((Y_train(i, non_miss_ind) - ground_truth(i))' * (Y_train(i, non_miss_ind) - ground_truth(i)), V_mat_div_Q_mat, miss_ind);
            Sigma_gradient = Sigma_gradient + temp;
        end
        
        % collect gradient information from unlabeled data points
        for i = 1 : Nu
            class_index = Date_class(i);
            miss_ind = missing_ind_train(i, :);
            non_miss_ind = ~miss_ind;
            
            Q_mat = Sigma_inv(miss_ind, miss_ind);
            V_mat = Sigma_inv(non_miss_ind, miss_ind);
            ones_vector = ones(sum(non_miss_ind), 1);
            U_mat = Sigma_inv(non_miss_ind, non_miss_ind);
            V_mat_div_Q_mat = V_mat / Q_mat;
            U_prim_mat = U_mat - V_mat_div_Q_mat * V_mat';
            
            collected_num = collected_num_T(class_index);
            U_tilde_Nu_T{class_index}(collected_num, collected_num) = sum(U_prim_mat(:));
            Y_tilde_Nu_T{class_index}(collected_num) = Yu_train(i, non_miss_ind) * U_prim_mat * ones_vector;
            
            temp = zeros(K);
            temp(miss_ind, miss_ind) = inv(Q_mat);
            temp = temp + get_missing_data_matrix(Yu_train(i, non_miss_ind)' * Yu_train(i, non_miss_ind), V_mat_div_Q_mat, miss_ind);
            vector_diagonal_matrixs_T{class_index}(:, :, collected_num) = get_missing_data_matrix(ones(sum(non_miss_ind)), V_mat_div_Q_mat, miss_ind);
            vector_mixed_matrixs_T{class_index}(:, :, collected_num) = get_missing_data_matrix(ones_vector * Yu_train(i, non_miss_ind) + Yu_train(i, non_miss_ind)' * ones_vector', V_mat_div_Q_mat, miss_ind);
            Sigma_gradient = Sigma_gradient + temp;
            
            if (N_u_T{class_index} == collected_num)
                p_l = Date_class(Nu + 1 : end) == class_index;
                ps = inv(U_tilde_Nu_T{class_index} + rv * laplacian_u_matrix_T{class_index});
                if (N_l_T{class_index} > 0)
                    vi_T{class_index} = ps * (Y_tilde_Nu_T{class_index} - rv * laplacian_lu_matrix_T{class_index}' * y_l(p_l) + rv * laplacian_lu_matrix_T{class_index}' * m_train_T{class_index}(N_u_T{class_index} + 1 : end) + rv * laplacian_u_matrix_T{class_index} * m_train_T{class_index}(1 : N_u_T{class_index}));
                else
                    vi_T{class_index} = ps * (Y_tilde_Nu_T{class_index} + rv * laplacian_u_matrix_T{class_index} * m_train_T{class_index}(1 : N_u_T{class_index}));
                end
                ph = vi_T{class_index} * vi_T{class_index}';
                diag_ph = diag(ph);
                diag_ps = diag(ps);
                for j = 1 : K
                    for l = 1 : j
                        diagonal_vector = squeeze(vector_diagonal_matrixs_T{class_index}(j, l, :));
                        Phi_T{class_index}(j, l) = diag_ph' * diagonal_vector;
                        Phi_T{class_index}(l, j) = Phi_T{class_index}(j, l);
                        Psi_T{class_index}(j, l) = diag_ps' * diagonal_vector;
                        Psi_T{class_index}(l, j) = Psi_T{class_index}(j, l);
                    end
                end
                temp_matrix = bsxfun(@times,  vector_mixed_matrixs_T{class_index}, reshape(vi_T{class_index}, [1 1 N_u_T{class_index}]));
                Sigma_gradient = Sigma_gradient + (Phi_T{class_index} + Psi_T{class_index} - sum(temp_matrix(:, :, :), 3));
            end
            collected_num_T(class_index) = collected_num + 1;
        end
        
        Sigma_gradient = (Nu + Nl) .* Sigma - Sigma_gradient;
        if (n <= Sigma_iters)
            Sigma_inv = Sigma_inv + learning_rate_Sigma * Sigma_gradient ./ N;
            Sigma_inv = projectToNearestPSD(Sigma_inv);
        end
    end
    
    % gradient ascent on scale parameter
    for i = 1 : scale_parameter_iters
        rv_gradient = 0;
        for t = 1 : T
            ps = inv(U_tilde_Nu_T{t} + rv * laplacian_u_matrix_T{t});
            p_l = Date_class(Nu + 1 : end) == t;
            if (N_l_T{t} > 0)
                vi_T{t} = ps * (Y_tilde_Nu_T{t} - rv * laplacian_lu_matrix_T{t}' * y_l(p_l) + rv * laplacian_lu_matrix_T{t}' * m_train_T{t}(N_u_T{t} + 1 : end) + rv * laplacian_u_matrix_T{t} * m_train_T{t}(1 : N_u_T{t}));
                rv_gradient = rv_gradient - trace(ps * laplacian_u_matrix_T{t}) + (N_u_T{t} + N_l_T{t}) / rv - trace(vi_T{t} * vi_T{t}' * laplacian_u_matrix_T{t}) - 2 * vi_T{t}' * (laplacian_lu_matrix_T{t}' * y_l(p_l) - laplacian_lu_matrix_T{t}' * m_train_T{t}(N_u_T{t} + 1 : end)...
                    - laplacian_u_matrix_T{t} * m_train_T{t}(1 : N_u_T{t})) + 2 * y_l(p_l)' * (laplacian_l_matrix_T{t} * m_train_T{t}(N_u_T{t} + 1 : end) + laplacian_lu_matrix_T{t} * m_train_T{t}(1 : N_u_T{t})) ...
                    - y_l(p_l)' * laplacian_l_matrix_T{t} * y_l(p_l) - m_train_T{t}' * laplacian_matrix_T{t} * m_train_T{t};
            else
                vi_T{t} = ps * (Y_tilde_Nu_T{t} + rv * laplacian_u_matrix_T{t} * m_train_T{t}(1 : N_u_T{t}));
                rv_gradient = rv_gradient - trace(ps * laplacian_u_matrix_T{t}) + (N_u_T{t} + N_l_T{t}) / rv - trace(vi_T{t} * vi_T{t}' * laplacian_u_matrix_T{t}) + 2 * vi_T{t}' * laplacian_u_matrix_T{t} * m_train_T{t}(1 : N_u_T{t}) - m_train_T{t}' * laplacian_matrix_T{t} * m_train_T{t};
            end
        end
        rv_gradient = rv_gradient * rstd;
        rstd = rstd + learning_rate_scale_parameter * rv_gradient ./ N ;
        rv = rstd^2;
    end
    
    % alternate optimization on default AOD means
    for i = 1 : mu_iters
        for r = 1 : R
            for class_index = 1 : T
                if (N_u_T{class_index} > 0)
                    ps = inv(U_tilde_Nu_T{class_index} + rv * laplacian_u_matrix_T{class_index});
                    p_l = Date_class(Nu + 1 : end) == class_index;
                    if (N_l_T{class_index} > 0)
                        tep = (pi_ir_T{class_index}(N_u_T{class_index} + 1 : end, r)' * rv * laplacian_lu_matrix_T{class_index} + pi_ir_T{class_index}(1 : N_u_T{class_index}, r)' * rv * laplacian_u_matrix_T{class_index});
                        m_nominator(r) = m_nominator(r) + tep * (ps * (Y_tilde_Nu_T{class_index} - rv * laplacian_lu_matrix_T{class_index}' * y_l(p_l) + rv * laplacian_lu_matrix_T{class_index}' * (m_train_T{class_index}(N_u_T{class_index} + 1 : end) - m_R(r) * pi_ir_T{class_index}(N_u_T{class_index} + 1 : end, r))...
                            + rv * laplacian_u_matrix_T{class_index} * (m_train_T{class_index}(1 : N_u_T{class_index}) - m_R(r) * pi_ir_T{class_index}(1 : N_u_T{class_index}, r))) - m_train_T{class_index}(1 : N_u_T{class_index}) + m_R(r) * pi_ir_T{class_index}(1 : N_u_T{class_index}, r))...
                            + (pi_ir_T{class_index}(N_u_T{class_index} + 1 : end, r)' * rv * laplacian_l_matrix_T{class_index} + pi_ir_T{class_index}(1 : N_u_T{class_index}, r)' * rv * laplacian_lu_matrix_T{class_index}') * (y_l(p_l) - m_train_T{class_index}(N_u_T{class_index} + 1 : end) + m_R(r) * pi_ir_T{class_index}(N_u_T{class_index} + 1 : end, r));
                        m_denominator(r) = m_denominator(r) + pi_ir_T{class_index}(:, r)' * rv * laplacian_matrix_T{class_index} * pi_ir_T{class_index}(:, r) - tep * ps * tep';
                    else
                        tep = pi_ir_T{class_index}(1 : N_u_T{class_index}, r)' * rv * laplacian_u_matrix_T{class_index};
                        m_nominator(r) = m_nominator(r) + tep * (ps * (Y_tilde_Nu_T{class_index} + rv * laplacian_u_matrix_T{class_index} * (m_train_T{class_index}(1 : N_u_T{class_index}) - m_R(r) * pi_ir_T{class_index}(1 : N_u_T{class_index}, r))) - m_train_T{class_index}(1 : N_u_T{class_index}) + m_R(r) * pi_ir_T{class_index}(1 : N_u_T{class_index}, r));
                        m_denominator(r) = m_denominator(r) + pi_ir_T{class_index}(:, r)' * rv * laplacian_matrix_T{class_index} * pi_ir_T{class_index}(:, r) - tep * ps * tep';
                    end
                end
            end                       
            if (m_denominator(r) ~= 0)    
                m_R(r) =  m_nominator(r) / m_denominator(r);         
            end
            m_nominator(r) = 0;
            m_denominator(r) = 0;
            for t = 1 : T
                N_T = N_u_T{t} + N_l_T{t};
                for j = 1 : N_T
                    m_train_T{t}(j) = pi_ir_T{t}(j, :) * m_R;
                end;
            end;            
        end
    end

    % gradient ascent on prototype vectors and scaling matrices
    q_gradient(:) = 0;
    for r = 1 : R
        Lambda_gradient{r}(:) = 0;
    end
    for t = 1 : T
        if (N_u_T{t} > 0)
            N_T = N_u_T{t} + N_l_T{t};
            p_l = Date_class(Nu + 1 : end) == t;
            if (N_l_T{t} > 0)
                temp_u = rv * laplacian_u_matrix_T{t} * (vi_T{t} - m_train_T{t}(1 : N_u_T{t})) + rv * laplacian_lu_matrix_T{t}' * (y_l(p_l) - m_train_T{t}(N_u_T{t} + 1 : end));
                temp_l = rv * laplacian_lu_matrix_T{t} * (vi_T{t} - m_train_T{t}(1 : N_u_T{t})) + rv * laplacian_l_matrix_T{t}' * (y_l(p_l) - m_train_T{t}(N_u_T{t} + 1 : end));
            else
                temp_u = rv * laplacian_u_matrix_T{t} * (vi_T{t} - m_train_T{t}(1 : N_u_T{t}));
            end
            for i = 1 : N_u_T{t}
                for r = 1 : R
                    q_gradient(r, :) = q_gradient(r, :) + (Lambda{r} * (X_train_T{t}(i, :) - q(r, :))' * (pi_ir_T{t}(i, r) * m_R(r) - pi_ir_T{t}(i, r) * pi_ir_T{t}(i, :) * m_R) * temp_u(i))';
                    Lambda_gradient{r} = Lambda_gradient{r} + (q(r, :) - X_train_T{t}(i, :))' * (X_train_T{t}(i, :) - q(r, :)) * (pi_ir_T{t}(i, r) * m_R(r) - pi_ir_T{t}(i, r) * pi_ir_T{t}(i, :) * m_R) * temp_u(i);
                end;
            end;
            for i = N_u_T{t} + 1 : N_T
                for r = 1 : R
                    q_gradient(r, :) = q_gradient(r, :) + (Lambda{r} * (X_train_T{t}(i, :) - q(r, :))' * (pi_ir_T{t}(i, r) * m_R(r) - pi_ir_T{t}(i, r) * pi_ir_T{t}(i, :) * m_R) * temp_l(i - N_u_T{t}))';
                    Lambda_gradient{r} = Lambda_gradient{r} + (q(r, :) - X_train_T{t}(i, :))' * (X_train_T{t}(i, :) - q(r, :)) * (pi_ir_T{t}(i, r) * m_R(r) - pi_ir_T{t}(i, r) * pi_ir_T{t}(i, :) * m_R) * temp_l(i - N_u_T{t});
                end;
            end;
        end
    end;
    
    q = q + learning_rate_q * q_gradient ./ N;
    for r = 1 : R
        Lambda{r} = Lambda{r} + learning_rate_Lambda * Lambda_gradient{r} ./ N;
        Lambda{r} = projectToNearestPSD(Lambda{r});
    end

    % print current states of parameters during training
    diff = norm(Sigma_gradient, 'fro');
    fprintf('current iteration: %d\n', iters + 1);
    fprintf('gradient norm of Sigma is %f\n', diff);
    fprintf('gradient of scale parameter is %f\n', rv_gradient); 
    q
    m_R  
    temp_diag = diag(Sigma)'
    iters = iters + 1;
end
    
Sigma = inv(Sigma_inv);
scale_parameter = 1 / rv;
end

% from the code of the paper Djuric et al., 'Semi-Supervised Learning for Integration of Aerosol Predictions from Multiple Satellite Instruments', IJCAI 2013.
% arrange the covaraince matrix according to the missing measurements of the corresponding data point
function return_mat = get_missing_data_matrix(input_mat, V_mat_div_Q_mat, miss_ind)
return_mat = zeros(length(miss_ind));
return_mat(~miss_ind, ~miss_ind) = input_mat;
return_mat(~miss_ind, miss_ind) = -input_mat' * V_mat_div_Q_mat;
return_mat(miss_ind, ~miss_ind) = return_mat(~miss_ind, miss_ind)';
return_mat(miss_ind, miss_ind) = V_mat_div_Q_mat' * input_mat * V_mat_div_Q_mat;
end

function [Date_class, T] = assignDataWithTime(Date_train)
[C, ~, ic] = unique(Date_train);
T = length(C);
Date_class = ic;
end

% project the covaraince matrix to psd cone
function X = projectToNearestPSD(C)
if (sum(isnan(C(:))) == 0 && sum(isinf(C(:))) == 0)
    [V, D] = eig(full(C));
    D_vector = diag(D);
    postest = D_vector <= 0;
    D_vector(postest) = 0.001;
    X = V * diag(D_vector) * V';
else
    X = eye(size(C, 1));
end
end
